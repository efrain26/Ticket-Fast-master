package mx.odelant.printorders.activity.start

import java.util.*

class RegistrationData(val dateStart: Calendar, val dateEnd: Calendar)
